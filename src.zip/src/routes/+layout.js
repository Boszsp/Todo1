export const ssr = false
export const prerender = true
export const trailingSlash = "never"
